using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.Net.Http.Headers;

namespace SampleSecureDeep.Models;

public class Student
{
    [Key]
    public string Nim { get; set; } = null!;
    public string FullName { get; set; } = null!;
}